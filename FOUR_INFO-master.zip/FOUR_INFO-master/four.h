//---------------------------------------------------------------------------

#ifndef fourH
#define fourH
//---------------------------------------------------------------------------
 #include <vcl.h>
 #include "dask.h"


class four{

	   double IDCard;

	public:

		four();
		~four();
		int	Lecture();
		void Ecriture(float tension);



};



#endif

